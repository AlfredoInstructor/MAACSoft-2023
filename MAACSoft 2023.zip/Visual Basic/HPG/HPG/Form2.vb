﻿Public Class Form2

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Close()

    End Sub

    Private Sub NUEVOToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUEVOToolStripMenuItem.Click
        Form3.Show()

    End Sub

    Private Sub BUSCARToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BUSCARToolStripMenuItem1.Click
        Form9.Show()


    End Sub

    Private Sub NUEVOToolStripMenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUEVOToolStripMenuItem2.Click
        Form5.Show()

    End Sub

    Private Sub NUEVOToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUEVOToolStripMenuItem1.Click
        Form4.Show()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Form6.Show()

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Form7.Show()

    End Sub

    Private Sub BUSCARToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BUSCARToolStripMenuItem.Click
        Form8.Show()

    End Sub

    Private Sub BUSCARToolStripMenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BUSCARToolStripMenuItem2.Click
        Form10.Show()

    End Sub

    Private Sub MODIFICARToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MODIFICARToolStripMenuItem.Click
        Form11.Show()

    End Sub
End Class